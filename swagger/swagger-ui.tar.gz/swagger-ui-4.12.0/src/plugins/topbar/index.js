import Topbar from "./topbar"

export default function () {
  return {
    components: {
      Topbar
    }
  }
}
